import express from 'express';

import {
  registrarUsuario,
  iniciarSesion,
  iniciarSesionGoogle,
  obtenerUsuario,
  solicitarRecuperacion,
  restablecerPassword,
  restablecerConCodigo,
  actualizarUsuario,
  verificarCuenta,
  reenviarCodigo,
  cambiarRolUsuario
} from '../controllers/userController.js';

import verificarToken, {
  verificarDueño,
  verificarAdmin
} from '../middleware/authMiddleware.js';

import {
  limitarLogin,
  limitarRegistro,
  limitarRecuperacion
} from '../middleware/rateLimiter.js';

import validar from '../middleware/validar.js';

import {
  registroSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  resetConCodigoSchema,
  verificarCuentaSchema,
  reenviarCodigoSchema
} from '../validators/userValidator.js';

import crearUploadMiddleware from '../middleware/uploadMiddleware.js';

const router = express.Router();

const uploadUserImage =
  crearUploadMiddleware('users');


// ======================================================
// REGISTRO
// ======================================================

router.post(
  '/register',
  limitarRegistro,
  validar(registroSchema),
  registrarUsuario
);


// ======================================================
// LOGIN
// ======================================================

router.post(
  '/login',
  limitarLogin,
  validar(loginSchema),
  iniciarSesion
);


// ======================================================
// LOGIN CON GOOGLE
// ======================================================

router.post(
  '/google',
  limitarLogin,
  iniciarSesionGoogle
);


// ======================================================
// VERIFICAR CUENTA
// ======================================================

router.post(
  '/verificar-cuenta',
  limitarLogin,
  validar(verificarCuentaSchema),
  verificarCuenta
);


// ======================================================
// REENVIAR CÓDIGO
// ======================================================

router.post(
  '/reenviar-codigo',
  limitarRecuperacion,
  validar(reenviarCodigoSchema),
  reenviarCodigo
);


// ======================================================
// RECUPERAR CONTRASEÑA (envía un código de 6 dígitos)
// ======================================================

router.post(
  '/forgot-password',
  limitarRecuperacion,
  validar(forgotPasswordSchema),
  solicitarRecuperacion
);


// ======================================================
// RESTABLECER CONTRASEÑA CON CÓDIGO
// ======================================================

router.post(
  '/reset-password',
  limitarLogin,
  validar(resetConCodigoSchema),
  restablecerConCodigo
);


// ======================================================
// RESTABLECER CONTRASEÑA (enlace antiguo, se conserva)
// ======================================================

router.post(
  '/reset-password/:token',
  validar(resetPasswordSchema),
  restablecerPassword
);


// ======================================================
// CAMBIAR ROL DE USUARIO
// SOLO ADMIN
// ======================================================

router.put(
  '/admin/rol',
  verificarToken,
  verificarAdmin,
  cambiarRolUsuario
);


// ======================================================
// OBTENER USUARIO
// ======================================================

router.get(
  '/:id',
  verificarToken,
  verificarDueño,
  obtenerUsuario
);


// ======================================================
// ACTUALIZAR USUARIO
// ======================================================

router.put(
  '/:id',
  verificarToken,
  verificarDueño,
  uploadUserImage.single('imagen'),
  actualizarUsuario
);


export default router;